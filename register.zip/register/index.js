const express = require("express");
const mongoose = require("mongoose");
const bodyParser = require("body-parser");
const dotenv = require("dotenv");
const cookieParser = require("cookie-parser");
const setupLoginRoute = require("./routes/login");
const setupAddRoute = require("./routes/about");
const setupContactRoute = require("./routes/Contact");
const setupdeliverRoute = require("./routes/deliver");
const setuporder1Route = require("./routes/order1");
const setuppay1Route = require("./routes/pay1");


const { cookieJwtAuth } = require("./middleware/cookiejwtauth");
const app = express();
dotenv.config();

// MongoDB Connection
const username = process.env.MONGODB_USERNAME;
const password = encodeURIComponent(process.env.MONGODB_PASSWORD); 
const mongoURI = `mongodb+srv://${username}:${password}@cluster0.oopkx.mongodb.net/registrationformDB?retryWrites=true&w=majority`;

mongoose.connect(mongoURI)
    .then(() => console.log("Connected to MongoDB"))
    .catch(err => console.error("Connection error", err));

// Registration Schema and Model
const registrationSchema = new mongoose.Schema({
    name: String,
    email: String,
    password: String,
});
const Registration = mongoose.model('Registration', registrationSchema);

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(cookieParser());

// Serve public assets (non-protected)
app.use("/public", express.static("public"));

// Public routes
app.get("/", (req, res) => res.sendFile(__dirname + "/public/index.html"));
app.get("/login.html", (req, res) => res.sendFile(__dirname + "/public/login.html"));
app.get("/register.html", (req, res) => res.sendFile(__dirname + "/public/register.html"));
app.get("/error.html", (req, res) => res.sendFile(__dirname + "/public/error.html"));
// Registration route
app.post('/register', async (req, res) => {
    const { name, email, password } = req.body;

    const existingUser = await Registration.findOne({ email });
    if (existingUser) {
        return res.redirect('/error.html');
    }

    const newUser = new Registration({ name, email, password });
    await newUser.save();

    res.redirect('/');
});

// Protected route for about.html
app.get("/about.html", cookieJwtAuth, (req, res) => {
    res.sendFile(__dirname + "/public/about.html");
});

// Login and additional routes setup

setupLoginRoute(app, Registration);
setupAddRoute(app);
setupContactRoute(app);
setupdeliverRoute(app);
setuporder1Route(app);
setuppay1Route(app);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
