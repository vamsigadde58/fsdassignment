const express = require("express");
const path = require("path");
const { cookieJwtAuth } = require("../middleware/cookiejwtauth");

module.exports = (app) => {
    app.get("/deliver.html", cookieJwtAuth, (req, res) => {
        res.sendFile(path.join(__dirname, "../public/deliver.html")); // Use path.join for safety
    });
};
