const jwt = require("jsonwebtoken");

module.exports = (app, Registration) =>
  app.post("/login", async (req, res) => {
    const { mail, pswd } = req.body;

    const user = await Registration.findOne({ email: mail, password: pswd });

    if (!user) {
      return res.redirect("/error.html");
    }

    const userData = { id: user._id, email: user.email };
    const token = jwt.sign(userData, process.env.JWT_SECRET, { expiresIn: "1h" });

    res.cookie("authToken", token, {
      httpOnly: true,
    });

    return res.redirect("/");
  });
